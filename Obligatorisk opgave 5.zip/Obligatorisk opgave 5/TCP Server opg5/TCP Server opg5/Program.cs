﻿using System;

namespace TCP_Server_opg5 {
    class Program {
        static void Main(string[] args) {
            ServerClient client = new ServerClient();
            client.Start();
        }
    }
}

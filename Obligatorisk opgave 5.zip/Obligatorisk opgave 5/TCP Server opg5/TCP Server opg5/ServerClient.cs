﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace TCP_Server_opg5 {
    class ServerClient {

        ManageItems manage = new ManageItems();

        public void Start() {
            TcpListener listener = new TcpListener(2121);
            listener.Start();
            while(true) {
                TcpClient socket = listener.AcceptTcpClient();
                Task.Run(() => DoClient(socket));
            }
        }

        public void DoClient(TcpClient socket) {
            using(StreamReader sr = new StreamReader(socket.GetStream())) 
            using(StreamWriter sw = new StreamWriter(socket.GetStream())) {
                bool isRunning = true;
                sw.WriteLine("Connected!");
                Console.WriteLine("Connected!");
                while(isRunning) {
                    string str = sr.ReadLine();
                    string[] readstr = str.Split(' ');
                    switch (readstr[0]) {
                        case "HentAlle":
                            foreach (Footballplayer p in manage.Get()) {
                                Console.WriteLine(p);
                                sw.WriteLine(p);
                            }
                        break;

                        case "Hent":
                            Console.WriteLine(manage.Get(Convert.ToInt16(readstr[1])));
                            sw.WriteLine(manage.Get(Convert.ToInt16(readstr[1])));
                        break;

                        case "Gem":
                            try {
                                if (manage.Create(new Footballplayer(readstr[1], Convert.ToInt16(readstr[2]), Convert.ToInt16(readstr[3])))) {
                                    Console.WriteLine("The player has been added to the system");
                                    sw.WriteLine("The player has been added to the system");
                                }
                            }catch(Exception e) {
                                Console.WriteLine(e.Message);
                                sw.WriteLine(e.Message);
                            }
                        break;

                        default:
                            sw.WriteLine("Hejhej");
                            Console.WriteLine("Hejhej");
                            isRunning = false;
                        break;
                    }
                    sw.Flush();
                }
            }
            socket?.Close();
        }
    }
}
